1.Install python3

2.Click install_pylib.bat to install iap.py dependency

3.enjoy it
